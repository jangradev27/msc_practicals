#include<iostream>
#include<vector>
#include<unordered_map>
#include<unordered_set>
#include<climits>
#include<cstdlib>
#include<random>
#include<fstream>
#include<ctime>
#include<string>
#include <chrono>

using namespace std;

class customHash{
    public:
        size_t operator()(const pair<int,int> a) const{
            size_t first=a.first;
            size_t second=a.second;

            return first << (first^second);
        }
};


class Graph{

    int n;
    unordered_map<int,unordered_set<int>> adjlist;
    vector<pair<int,int>> edges;
    int fileCounter;

    public:
        Graph(int n,int i){
            this->n=n;
            this->fileCounter=i;
        }

        void insertEdge(int u,int v){
            if(u>this->n || u<1 || v>this->n || v<1){
                cout<<"edges must be between 1 and "<<n<<endl;
                return;
            }

            adjlist[u].insert(v);
            adjlist[v].insert(u);

            edges.push_back({u,v});
            edges.push_back({v,u});
        }

        void showAdjList(){

             for(auto it=adjlist.begin();it!=adjlist.end();it++){
                 cout<<it->first<<"-> ";

                 for(auto &i:it->second){
                     cout<<i<<" ";
                 }

                 cout<<endl;
             }
        }

       bool checkIsVertexCover(vector<int> &sub){

            bool valid=true;

            for(auto p:this->edges){
                
                int u=p.first;
                int v=p.second;
                bool found=false;

                for(int i=0;i<sub.size();i++){
                    if(sub[i]==u || sub[i]==v){
                        found=true;
                    }
                }

                if(!found){
                    valid=false;
                }
            }

            return valid;
        }

        void createVertexSet(int V,vector<int> &temp,vector<int> &ans,int i=1){

            if(i>V){

                auto validVertex=checkIsVertexCover(temp);

                if(validVertex){

                    if(ans.size()==0 || temp.size()<ans.size()){
                        ans=temp;
                    }
                }

                return;
            }

            temp.push_back(i);

            createVertexSet(V,temp,ans,i+1);

            temp.pop_back();

            createVertexSet(V,temp,ans,i+1);
        }

        void dfs(int src, vector<bool> &visited){

            visited[src]=true;

            for(auto &j:adjlist[src]){

                if(!visited[j]){
                    dfs(j,visited);
                }
            }
        }

        bool isConnected(){

            vector<bool> visited(n+1,false);

            int count=0;

            for(int i=1;i<=n;i++){

                if(!visited[i]){

                    count++;

                    dfs(i,visited);
                }
            }

            return count==1;
        }

        vector<int> findVertexCover(){

            vector<int> temp;

            vector<int> vertexCover;

            createVertexSet(this->n,temp,vertexCover);

            
                   
            
            return vertexCover;  
        }
        
        // void visualizerGraph(){
            
        //    ofstream file("data.json");
        //    file << "{\n";

        //    file<<"\"edges\" :[ ";

        //     for(int i=0;i<edges.size();i++){
        //         file << "[" <<edges[i].first << "," << edges[i].second<<"]";

        //         if(i!=edges.size()-1)
        //     }
            
            
        // }

        void writeOutputinFile(vector<int> &vertexCover,string time){
            string str="output" + to_string(fileCounter+1) + ".txt";
            ofstream fileTwo("./data/" + str);
            fileTwo<<"[";

            for(int i=0;i<vertexCover.size();i++){

                fileTwo<<vertexCover[i];

                if(i!=vertexCover.size()-1){
                    fileTwo<<",";
                }
            }

            fileTwo<<"]"<<endl;

            fileTwo<<vertexCover.size()<<endl<<time<<endl<<endl;
        }

};


int main(){

    int n = 10;

    Graph *g = NULL;

    srand(time(0));

    vector<int> noOfEdges = {10, 15, 20, 25, 30, 35, 40, 45};

    for(int counter = 0; counter < noOfEdges.size(); counter++){

        string str = "input" + to_string(counter + 1) + ".txt";
        ofstream fileOne("./data/" + str);

        int E = noOfEdges[counter];

        fileOne << "10" << " " << E;

        vector<pair<int,int>> edges;


        g = new Graph(n, counter);

        unordered_map<pair<int,int>, bool, customHash> isValidEdge;

        for(int i = 1; i < n; i++){

            int u = i;
            int v = i + 1;

            edges.push_back({u, v});

            g->insertEdge(u, v);

            isValidEdge[{u, v}] = true;
            isValidEdge[{v, u}] = true;
        }

        int remainingEdges = E - 9;
        int count = 0;

        while(count < remainingEdges){

            int u = (rand() % n) + 1;
            int v = (rand() % n) + 1;

            if(u == v)
                continue;

            if(isValidEdge[{u, v}] ||
               isValidEdge[{v, u}])
                continue;

            edges.push_back({u, v});

            g->insertEdge(u, v);

            isValidEdge[{u, v}] = true;
            isValidEdge[{v, u}] = true;

            count++;
        }


        fileOne << "\n[ ";

        for(int i = 0; i < edges.size(); i++){

            fileOne << "[" 
                    << edges[i].first 
                    << "," 
                    << edges[i].second 
                    << "]";

            if(i != edges.size() - 1){
                fileOne << " , ";
            }
        }

        fileOne << " ]" << endl << endl;

        auto start= chrono::high_resolution_clock:: now();

        auto vertexCover=g->findVertexCover();

        auto end= chrono::high_resolution_clock:: now();
        auto duration = chrono::duration_cast<chrono::microseconds>(end - start);
        
        g->writeOutputinFile(vertexCover,to_string(duration.count())+"ms");

        delete g;
        g = NULL;
    }

    system("python visualize.py");
    return 0;
}