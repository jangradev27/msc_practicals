import networkx as nx
import matplotlib.pyplot as plt
def DrawGraph(no_of_edges,edges,vertexCover,counter,timeTaken):
    graph=nx.Graph();

    for i in edges:
        u=i[0];
        v=i[1];
        graph.add_edge(u,v);
    
    node_colors = [];
    for node in graph.nodes():
        if node in vertexCover:
            node_colors.append("red");
        else:
            node_colors.append("blue");


    plt.figure(figsize=(10,10),);
    
    nx.draw(graph,label="vertex Cover",with_labels=True,node_color=node_colors,font_color='white');
    plt.title(
        f"Vertex Cover Size: {len(vertexCover)}\n"
        f"No. of Edges: {no_of_edges}\n"
        f"Time Taken:{timeTaken}"
    );
    plt.savefig(
        f"./visualized_graph/graph{counter}.png",
        dpi=300,
        bbox_inches="tight"
    )
    plt.show();


for i in range(1,9):
    inputfile= open(f"./data/input{i}.txt");
    outputfile=open(f"./data/output{i}.txt");
    inputdata=inputfile.readlines();
    outputdata=outputfile.readlines();

    no_of_edges=int(inputdata[0].split(" ")[1]);
    print(no_of_edges);
    edges=eval(inputdata[1]);

    vertexCover=eval(outputdata[0]);
    timeTaken=outputdata[2];
    print(vertexCover);
    DrawGraph(no_of_edges,edges,vertexCover,i,timeTaken);
    
